<?php
/**
 * 快云免流管理中心
 * by 飞跃 2017年5月6日
 */
include("../../Data/api.inc.php");
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='../Kyun/index.php';</script>");
?>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>卡密管理 - 卡密列表</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="../favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css?v=4.4.0" rel="stylesheet">

    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css?v=4.1.0" rel="stylesheet">

</head>

<body class="gray-bg">

<div class="wrapper wrapper-content animated fadeInUp">
<div class="row">
<div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;width: 100%">
<section class="panel panel-default">
  <div class="ibox-title">
                        <h5>卡密管理 >><small>卡密列表</small></h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
<div class="panel-body">
				
<div class="form-group">
  <?php
function getkm($len = 18)
{
	$str = "09876543210123456789";
	$strlen = strlen($str);
	$randstr = "";
	for ($i = 0; $i < $len; $i++) {
		$randstr .= $str[mt_rand(0, $strlen - 1)];
	}
	return $randstr;
}
$kind=1;
$my=isset($_GET['my'])?$_GET['my']:null;

if($my=='add'){
$kind=1;
$num=intval($_POST['num']);
$value=intval($_POST['value']);
$values=round($_POST['values'],2);
echo '
<div class="panel-heading w h"><h3 class="panel-title">成功生成以下卡密</h3></div>
<div class="panel-body box">';
for ($i = 0; $i < $num; $i++) {
$km=getkm(18);
$sql=$DB->query("insert into `auth_kms` (`kind`,`km`,`value`,`values`,`money`,`addtime`) values ('".$kind."','".$km."','".$value."','".$values."','0.00','".$date."')");
if($sql) {
echo ''.$km.'<br>';
}else{
echo'<div class="box">奥，该卡密已存在.</div>';}
}
echo '<hr/><a href="./kms_list.php" class="btn btn-success">返回卡密列表</a></div></div>';
}
elseif($my=='del'){
echo '
<div class="panel-heading w h"><h3 class="panel-title">删除卡密结果</h3></div>
<div class="panel-body box">';
$id=$_GET['id'];
$sql=$DB->query("DELETE FROM auth_kms WHERE id='$id'");
if($sql){
echo '<div class="box">恭喜亲成功删除卡密.</div>';
}else{
echo'<div class="box">奥，删除卡密失败，请重新尝试.</div>';}
echo '<hr/><a href="./kms_list.php" class="btn btn-success">返回卡密列表</a></div></div>';
}elseif($my=='qk'){//清空卡密结果
echo '
<div class="panel-heading w h"><h3 class="panel-title">清空平台所有卡密</h3></div>
<div class="panel-body box">';
if($DB->query("DELETE FROM auth_kms WHERE kind='1'")==true){
echo '<div class="box">恭喜亲成功清空平台所有卡密.</div>';
}else{
echo'<div class="box">奥，清空平台卡密失败，请重新尝试.</div>';
}
echo '<hr/><a href="./kms_list.php" class="btn btn-success">返回卡密列表</a></div></div>';
}

elseif($my=='sy'){//删除卡密结果
echo '
<div class="panel-heading w h"><h3 class="panel-title">删除已使用卡密</h3></div>
<div class="panel-body box">';
if($DB->query("DELETE FROM auth_kms WHERE isuse=1")==true){
echo '<div class="box">恭喜亲成功删除已使用卡密.</div>';
}else{
echo'<div class="box">奥，删除已使用卡密失败，请重新尝试.</div>';
}
echo '<hr/><a href="./kms_list.php" class="btn btn-success">返回卡密列表</a></div></div>';
}
else
{
if($my='chax'){
	if($_GET['type']==1) {
		$sql=" `km`='{$_GET['cha']}' and kind=1";
		$numrows=$DB->count("SELECT count(*) from auth_kms WHERE{$sql}");
	}
else{
	$numrows=$DB->count("SELECT count(*) from auth_kms WHERE kind=1");
	$sql=" kind=1";}	
}
echo '<form action="kms_list.php?my=add" method="POST" class="form-inline">
  <div class="form-group">
    <input type="text" class="form-control" name="num" placeholder="要生成多少张？">
  </div>
  <div class="form-group">
    <input type="text" class="form-control" name="value" placeholder="每个要开通多少天？">
  </div>
  <div class="form-group">
    <input type="text" class="form-control" name="values" placeholder="每个要多少GB流量呢？">
  </div>
  <button type="submit" class="btn btn-primary">生成</button>
  <a href="kms_list.php?my=qk" class="btn btn-danger">清空平台卡密</a>
  <a href="kms_list.php?my=sy" class="btn btn-danger">删除已使用卡密</a>
  <a href="#" class="btn btn-info">平台共有 <b>'.$numrows.'</b> 个卡密</a>
</form>';
?>
      <div class="table-responsive">
         <table class="table table-bordered table-hover">
         <thead><tr><th class="text-center">ID</th><th class="text-center">卡密</th><th class="text-center">状态</th><th class="text-center">套餐时间</th><th class="text-center">套餐流量</th><th class="text-center">使用者</th><th class="text-center">使用时间</th><th class="text-center">添加时间</th><th class="text-center">操作</th></tr></thead>
          <tbody>
<?php
$pagesize=50;
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}
else{
$page=1;
}
$offset=$pagesize*($page - 1);

$rs=$DB->query("SELECT * FROM auth_kms WHERE{$sql} order by id desc limit $offset,$pagesize");
while($res = $DB->fetch($rs))
{
if($res['isuse']==1) {
	$isuse='<span class="label label-danger">已使用</span>';
} elseif($res['isuse']==0) {
	$isuse='<span class="label label-primary">正常</span>';
}
if($res['usetime']==NULL){
$usetime='———';
}else{
$usetime=$res['usetime'];	
}
if($res['user']==NULL){
$user='———';
}else{
$user='<span class="label label-warning">'.$res['user'].'</span>';}
echo '<tr><td class="text-center">'.$res['id'].'</td><td class="text-center">'.$res['km'].'</td><td class="text-center">'.$isuse.'</td><td class="text-center">'.$res['value'].'</td><td class="text-center">'.$res['values'].' GB</td><th class="text-center">'.$user.'</th><td class="text-center">'.$usetime.'</td><td class="text-center">'.$res['addtime'].'</td><td class="text-center"><a href="./kms_list.php?my=del&id='.$res['id'].'" class="btn btn-xs btn-danger" onclick="return confirm(\'你确实要删除此卡密吗？\');">删除</a></td></tr>';
}
?>
          </tbody>
        </table>
      </div>
<?php
echo'<ul class="pagination">';
$first=1;
$prev=$page-1;
$next=$page+1;
$last=$pages;
if ($page>1)
{
echo '<li><a href="kms_list.php?page='.$first.$link.'">首页</a></li>';
echo '<li><a href="kms_list.php?page='.$prev.$link.'">&laquo;</a></li>';
} else {
echo '<li class="disabled"><a>首页</a></li>';
echo '<li class="disabled"><a>&laquo;</a></li>';
}
for ($i=1;$i<$page;$i++)
echo '<li><a href="kms_list.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '<li class="disabled"><a>'.$page.'</a></li>';
for ($i=$page+1;$i<=$pages;$i++)
echo '<li><a href="kms_list.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '';
if ($page<$pages)
{
echo '<li><a href="kms_list.php?page='.$next.$link.'">&raquo;</a></li>';
echo '<li><a href="kms_list.php?page='.$last.$link.'">尾页</a></li>';
} else {
echo '<li class="disabled"><a>&raquo;</a></li>';
echo '<li class="disabled"><a>尾页</a></li>';
}
echo'</ul>';
#分页
}
?>
    </div>

 
                  
              </div>
            </section>
			  </div>
                        </div>
                    </div>
                </div>

    <!-- 全局js -->
    <script src="../../assets/js/jquery.min.js?v=2.1.4"></script>
    <script src="../../assets/js/bootstrap.min.js?v=3.3.6"></script>


    <!-- 自定义js -->
    <script src="../../assets/js/content.js?v=1.0.0"></script>

    </body>
</html>
