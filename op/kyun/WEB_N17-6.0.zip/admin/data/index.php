<?php
/**
 * 快云免流管理中心
 * by 飞跃 2017年5月6日
 */
include("../../Data/api.inc.php");
if($islogin2==1){
$user=$DB->count("SELECT count(*) from `openvpn` WHERE 1");	
$kms=$DB->count("SELECT count(*) from auth_kms WHERE kind=1");
$kms2=$DB->count("SELECT count(*) from auth_kms WHERE kind=2");
$line=$DB->count("SELECT count(*) from line");
$line2=$DB->count("SELECT count(*) from line WHERE `show`='0'");
$gg=$DB->count("SELECT count(*) from ky_gg");
$row = $DB->get_row("SELECT * FROM kyun"); 	
echo '
<html>
<head>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width,user-scalable=no"/>
    <meta name="renderer" content="webkit">
    <title>管理员平台 - '.$row[logo].'</title>

    <meta name="keywords" content="快云免流，快云流控，快云流量，NB免流，NB流控">
    <meta name="description" content="快云免流，快云流控，快云流量，NB免流，NB流控">

    <link rel="shortcut icon" href="../../assets/img/favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="../../assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">
<style> 

</style> 
	
</head>
<body class="fixed-sidebar full-height-layout gray-bg" style="overflow:hidden">
    <div id="wrapper">
	 <!--左侧导航开始-->
        <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="nav-close"><i class="fa fa-times-circle"></i>
            </div>
            <div class="sidebar-collapse">
                <ul class="nav" id="side-menu">
                    <li class="nav-header">
                        <div class="dropdown profile-element">
                            <a data-toggle="dropdown" class="dropdown-toggle" href="N17_admin.php">
                                <span class="clear">
                                    <span class="block m-t-xs" style="font-size:20px;">
									 <img alt="image" class="img-circle"  height="160" width="160" src="'.$row[logo2].'"></img>
                                    </span>
                                </span>
                               </a>
                           </div>
						<div class="logo-element"><img alt="image" class="img-circle"  height="70" width="70" src="'.$row[logo2].'">
                       </div>
                     </li>
                    <li class="hidden-folded padder m-t m-b-sm text-muted text-xs">
                        <span class="ng-scope">数据信息</span>
                    </li>
                    <li>
                        <a class="J_menuItem" href="N17_admin.php">
                            <i class="fa fa-home"></i>
                            <span class="nav-label">平台首页</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="fa fa fa-bar-chart-o"></i>
                            <span class="nav-label">实时监控</span>
                            <span class="fa arrow"></span>
                        </a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a class="J_menuItem" href="online_list.php">在线检测</a>
                            </li>
                            <li>
                                <a class="J_menuItem" href="user_log.php">操作记录</a>
                            </li>
                        </ul>
                    </li>
                    <li class="line dk"></li>
                    <li class="hidden-folded padder m-t m-b-sm text-muted text-xs">
                        <span class="ng-scope">用户信息</span>
                    </li>
                    <li>
                      <a href="#"><i class="fa fa-qq fa-fw"></i><span class="nav-label">账号管理</span><span class="label label-info pull-right">New</span></a>
                        <ul class="nav nav-second-level">
                           <li><a class="J_menuItem" href="add_user.php">添加账号</a>
                            </li>
							<li><a class="J_menuItem" href="padd_user.php">批量添加账号</a>
                            </li>
                            <li><a class="J_menuItem" href="user_list.php">账号列表<span class="label label-info pull-right">'.$user.'</span></a>
                            </li>
							<li><a class="J_menuItem" href="user_area.php">用户分布情况<span class="label label-danger pull-right">New</span></a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-book"></i><span class="nav-label">卡密管理</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li><a class="J_menuItem" href="kms_list.php">卡密列表<span class="label label-info pull-right">'.$kms.'</span></a>
                            </li>
						   <li>
						    <a class="J_menuItem" href="daili_kms.php">代理充值卡密<span class="label label-warning pull-right">'.$kms2.'</span></a>
                            </li>
                            <li><a class="J_menuItem" href="suo_kms.php">搜索卡密</a>
                            </li>
                        </ul>
                    </li>
					 <li>
                        <a href="#"><i class="fa fa-cube"></i><span class="nav-label">套餐管理</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                           <li>
						    <a class="J_menuItem" href="add_taocan.php">添加新套餐</a>
                            </li>
							 <li><a class="J_menuItem" href="taocan_list.php">套餐列表</a>
                            </li>
                            <li><a class="J_menuItem" href="pay_set.php">支付接口设置</a>
                            </li>
							<li><a class="J_menuItem" href="buy_list.php">交易记录列表</a>
                            </li>
                        </ul>
                    </li>
					 <li>
                        <a href="#"><i class="fa fa-sitemap"></i><span class="nav-label">负载集群管理</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
							<li><a class="J_menuItem" href="add_note.php">添加新节点</a>
                            </li>
                           <li><a class="J_menuItem" href="note_list.php">节点列表</a>
                            </li>
						  <li><a class="J_menuItem" href="set_zhshu.php">修改线路证书</a>
                            </li>
                        </ul>
                    </li>
                    <li class="line dk"></li>
                    <li class="hidden-folded padder m-t m-b-sm text-muted text-xs">
                        <span class="ng-scope">代理信息</span>
                    </li>
                    <li>
                      <a href="#"><i class="fa fa-bookmark"></i><span class="nav-label">代理管理</span><span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
						 <li><a class="J_menuItem" href="add_daili.php">添加新代理</a>
                            </li>
						  <li><a class="J_menuItem" href="daili_list.php">代理用户列表</a>
                            </li>
							 <li><a class="J_menuItem" href="deu_daili.php">清空代理数据</a>
							 </li>
						 </ul>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-shield"></i><span class="nav-label">云端管理</span></a>
                        <ul class="nav nav-second-level">
						   <li><a class="J_menuItem" href="add_ggao.php">发布新公告</a>
                            </li>
							 <li><a class="J_menuItem" href="ggao_list.php">公告列表<span class="label label-info pull-right">'.$gg.'</span></a></a>
                            </li>
							<li><a class="J_menuItem" href="app_qq.php">软件客服</a>
                            </li>
							<li><a class="J_menuItem" href="shengji.php">启动图与更新</a>
                            </li>
							
                        </ul>
                    </li>
					  <li>
                        <a href="#"><i class="fa fa-comments"></i><span class="nav-label">线路管理</span><span class="label label-danger pull-right">Hot</span></a>
						 <ul class="nav nav-second-level">
						     
							<li><a class="J_menuItem" href="add_line.php">添加新线路</a>
                            </li>
                            <li><a class="J_menuItem" href="line_list.php">平台线路列表<span class="label label-info pull-right">'.$line.'</span></a>
                            </li>
							<li><a class="J_menuItem" href="fank_list.php">用户反馈列表</a>
                            </li>
							<li><a class="J_menuItem" href="line_check.php">代理线路审核<span class="label label-warning pull-right">'.$line2.'</span></a>
                            </li>
							<li><a class="J_menuItem" href="kyun_line.php">官方推送列表<span class="label label-warning pull-right">New</span></a>
                            </li>
                        </ul>
					 </li>
                    <li class="line dk"></li>
                    <li class="hidden-folded padder m-t m-b-sm text-muted text-xs">
                        <span class="ng-scope">服务信息</span>
                    </li>
					 <li>
                        <a href="#"><i class="fa fa-user-md"></i><span class="nav-label">高级管理 </span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
						 <li>
						  <a class="J_menuItem" href="daili_config.php">平台信息</a>
                            </li>
							 <li><a class="J_menuItem" href="user_kyun.php">管理员信息</a>
                            </li>
							<li>
                             <a class="J_menuItem" href="webxsu.php">系统服务设置</a>
                            </li>
						  <li><a class="J_menuItem" href="pass_set.php">修改密码</a>
                            </li>
                        </ul>
                    </li>
					<li>
                        <a href="../Kyun/index.php?logout"><i class="fa fa-sign-in"></i><span class="nav-label">退出登录</span></a>
				    </li>
                    <li>
                        <a href="#"><i class="fa fa-gears"></i><span class="nav-label">系统版本信息 </span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li><a class="J_menuItem">PHP 版本：'.PHP_VERSION.'</a>
                            </li>
                            <li><a class="J_menuItem">MySQL 版本：5.5.52</a>
                            </li>
                            <li><a class="J_menuItem">WEB 版本：N17-6.0  </a>
                            </li>
                        </ul>
                    </li>
                 </ul>
			   <br>
            </div>
        </nav>
        <!--左侧导航结束-->
        <!--右侧部分开始-->
         <div id="page-wrapper" class="gray-bg dashbard-1">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
                    <div class="navbar-header">
					  <a class="navbar-minimalize minimalize-styl-2 btn btn-info" href="#"><i class="fa fa-bars"></i> </a>
                        <form role="search" class="navbar-form-custom" method="post" action="#">
                            <div class="form-group">
                                <input type="text" placeholder="OpenVPN丨'.$row[logo].'" class="form-control" name="top-search" id="top-search">
                            </div>
                        </form>
                    </div> 
				   <div class="pull-right tooltip-demo">
                         <a class="btn btn-sm btn-white" href="../Kyun/index.php?logout"><i class="fa fa-sign-out fa-arrow-right"></i> 注销</a>
                        </div>
                </nav>
            </div>
        <div class="row J_mainContent" id="content-main">
                <iframe id="J_iframe" width="100%" height="100%" src="N17_admin.php" frameborder="0" data-id="N17_admin.php" scrolling="yes"></iframe>
         </div>  
     <!--右侧部分结束-->
    </div>

    <!-- 全局js -->
    <script src="../../assets/js/jquery.min.js?v=2.1.4"></script>
    <script src="../../assets/js/bootstrap.min.js?v=3.3.6"></script>
    <script src="../../assets/js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="../../assets/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>
    <script src="../../assets/js/plugins/layer/layer.min.js"></script>

    <!-- 自定义js -->
    <script src="../../assets/js/hAdmin.js?v=4.1.0"></script>
    <script type="text/javascript" src="../../assets/js/index.js"></script>

    <!-- 第三方插件 -->
    <script src="../../assets/js/plugins/pace/pace.min.js"></script>
</body>

</html>';
}else{exit("<script language='javascript'>window.location.href='../Kyun/index.php';</script>");}
?>