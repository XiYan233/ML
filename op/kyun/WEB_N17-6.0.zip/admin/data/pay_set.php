<?php
/**
 * 快云免流管理中心
 * by 飞跃 2017年5月6日
 */
include("../../Data/api.inc.php");
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='../Kyun/index.php';</script>");
$row = $DB->get_row("SELECT * FROM ky_pay"); 	
?>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>套餐管理 - 支付接口设置</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="../favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="../../assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">

</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-sm-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>套餐管理 >><small>支付接口设置</small></h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content">
<?php
if($_POST['key']){
echo '
<div class="panel-heading w h"><h3 class="panel-title">支付接口设置结果</h3></div>
<div class="panel-body box">';	
$user = daddslashes($_POST['user']);
$key = daddslashes($_POST['key']);
$url = daddslashes($_POST['url']);
$sql="update `ky_pay` set `user`='$user',`key`='$key',`url`='$url'";
if($DB->query($sql)){
echo '<div class="box">恭喜亲,成功设置支付接口</div>';	
}else{
echo '<div class="box">奥，支付接口设置失败,请稍后重新尝试.</div>';
}
echo '<hr/><a href="./pay_set.php" class="btn btn-success">返回支付接口设置</a></div></div>';}
else{
echo'			
                        <form action="./pay_set.php" class="form-horizontal m-t" method="post">
						    <div class="form-group has-error"> 
                                <label class="col-sm-3 control-label">快支付账号：</label>
                                <div class="col-sm-7">
                                    <input id="firstname" name="user" value="'.$row[user].'" class="form-control" type="text">
                                 </div>
								</div>
								
							 <div class="hr-line-dashed"></div>
							 <div class="form-group has-success">
                                <label class="col-sm-3 control-label">快支付KEY：</label>
                                <div class="col-sm-7">
                                    <input id="firstname" name="key" value="'.$row['key'].'" class="form-control" type="text">
                                </div>
							  </div>
							  
							 <div class="hr-line-dashed"></div>
							 <div class="form-group has-warning">
                                <label class="col-sm-3 control-label">支付返回URL：</label>
                                <div class="col-sm-7">
                                    <input id="firstname" name="url" value="'.$row[url].'" class="form-control" type="text">
                                </div>
							  </div>
							  
							 <div class="hr-line-dashed"></div>
                            <div class="form-group">
                                <div class="col-sm-8 col-sm-offset-3">
                                    <button class="btn btn-primary" type="submit">保存内容</button>
                                </div>
                            </div>
                        </form>';
}								
?>		
                    </div>
                </div>
            </div>
        </div>

    </div>

</body>

</html>
