<?php
/**
 * 快云免流管理中心
 * by 飞跃 2017年5月6日
 */
include("../../Data/api.inc.php");
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='../Kyun/index.php';</script>");
?>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>高级管理 - 管理员信息</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="../favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css?v=4.4.0" rel="stylesheet">

    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css?v=4.1.0" rel="stylesheet">

</head>

<body class="gray-bg">
<div class="wrapper wrapper-content animated fadeInUp">
<div class="row">
<div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;width: 100%">
<div class="panel panel-default">
  <div class="ibox-title">
                        <h5>高级管理 >><small>管理员信息</small></h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
          <div class="ibox-content">
<?php
$rs=$DB->get_row("SELECT * FROM kyun");
$my=$_POST['my'];
$qun=$_POST['qun'];
$fyue=$_POST['fyue'];
$qq=$_POST['qq'];
$app=$_POST['app'];
$zhifu=$_POST['zhifu'];
$gw=$_POST['gw'];
$logo=$_POST['logo'];
$logo2=$_POST['logo2'];
if($my=='kyun'){
echo '<div class="panel-heading w h"><h3 class="panel-title">保存信息结果</h3></div>
<div class="panel-body box">';
$sql=$DB->query("update `kyun` set `qun`='$qun',`fyue`='$fyue',`zhifu`='$zhifu',`logo`='$logo',`logo2`='$logo2',`gw`='$gw',`app`='$app',`qq`='$qq' where 1");
if($sql){echo '<div class="box">恭喜亲成功保存所有信息设置</div>';}
else{echo'<div class="box">噢，保存信息失败,请稍后重新尝试.</div>';}
echo '<hr/><a href="./user_kyun.php" class="btn btn-success">返回信息设置</a></div>';
exit;
}
?>				
      <form action="./user_kyun.php" method="post" class="form-horizontal" role="form">
			<div class="form-group has-success">
            	<input type="hidden" name="my" value="kyun"/>
              <label class="col-sm-2 control-label">交流群链接：</label>
			<div class="col-sm-8"><textarea class="form-control" name="qun" rows="2" cols="3" required><?php echo $rs['qun'];?></textarea></div>
            </div> 
			 <div class="hr-line-dashed"></div>
			 
			<div class="form-group has-error">
              <label class="col-sm-2 control-label">售后群链接：</label>
			<div class="col-sm-8"><textarea class="form-control" name="fyue" rows="2" cols="3" required><?php echo $rs['fyue'];?></textarea></div>
            </div> 
			<div class="hr-line-dashed"></div>
			
			<div class="form-group has-success">
              <label class="col-sm-2 control-label">商品购买地址</label>
				<div class="col-sm-3"><input type="text" class="form-control" name="zhifu" value="<?php echo $rs['zhifu'];?>"/></div>
             	<label class="col-sm-2 control-label">管理员QQ</label>
				<div class="col-sm-3"><input type="text" class="form-control" name="qq" value="<?php echo $rs['qq'];?>"/></div>
			 </div> 
			 <div class="hr-line-dashed"></div>
			 
			<div class="form-group has-warning">
              <label class="col-sm-2 control-label">平台Logo信息</label>
				<div class="col-sm-3"><input type="text" class="form-control" name="logo" value="<?php echo $rs['logo'];?>"/></div>
             	<label class="col-sm-2 control-label">Logo图片地址</label>
				<div class="col-sm-3"><input type="text" class="form-control" name="logo2" value="<?php echo $rs['logo2'];?>"/></div>
			 </div> 
			  <div class="hr-line-dashed"></div>
			  
			<div class="form-group has-success">
              <label class="col-sm-2 control-label">软件下载地址</label>
				<div class="col-sm-3"><input type="text" class="form-control" name="app" value="<?php echo $rs['app'];?>"/></div>
               <label class="col-sm-2 control-label">官方网站地址</label>
				<div class="col-sm-3"><input type="text" class="form-control" name="gw" value="<?php echo $rs['gw'];?>"/></div>
			 </div> 
			 <div class="hr-line-dashed"></div>
                            <div class="form-group">
                                <div class="col-sm-4 col-sm-offset-2">
                                    <button class="btn btn-primary" type="submit">保存当前设置</button>
                                </div>
                            </div>
          </form>
				
	    </div>				
            </div>
			  </div>
                        </div>
                    </div>
                </div>
    <!-- 自定义js -->
    <script src="../../assets/js/content.js?v=1.0.0"></script>

    </body>
</html>
