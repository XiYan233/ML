<?php
/**
 * 快云免流管理中心
 * by 飞跃 2017年5月6日
 */
include("../../Data/api.inc.php");
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='../Kyun/index.php';</script>");
?>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>高级管理 - 平台信息设置</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="../favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css?v=4.4.0" rel="stylesheet">

    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css?v=4.1.0" rel="stylesheet">

</head>

<body class="gray-bg">
<div class="wrapper wrapper-content animated fadeInUp">
<div class="row">
<div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;width: 100%">
<div class="panel panel-default">
  <div class="ibox-title">
                        <h5>高级管理 >><small>平台信息设置</small></h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
          <div class="ibox-content">
<?php
$rs=$DB->get_row("SELECT * FROM auth_config");
$regok=$rs['regok'];
$activeok=$rs['activeok'];
$dl0=$rs['dl0'];
$dl1=$rs['dl1'];
$dl2=$rs['dl2'];
$dl3=$rs['dl3'];
$dl4=$rs['dl4'];
$dl5=$rs['dl5'];
$dls0=$rs['dls0'];
$dls1=$rs['dls1'];
$dls2=$rs['dls2'];
$dls3=$rs['dls3'];
$dls4=$rs['dls4'];
$dls5=$rs['dls5'];
$gongg=$rs['gg'];
$gonggs=$rs['ggs'];
$my=$_POST['my'];
if($my=='config'){
echo '<div class="panel-heading w h"><h3 class="panel-title">保存信息结果</h3></div>
<div class="panel-body box">';
$ak=$_POST['ak'];
$rk=$_POST['rk'];
$dl00=$_POST['dl0'];
$dl01=$_POST['dl1'];
$dl02=$_POST['dl2'];
$dl03=$_POST['dl3'];
$dl04=$_POST['dl4'];
$dl05=$_POST['dl5'];
$dls00=$_POST['dls0'];
$dls01=$_POST['dls1'];
$dls02=$_POST['dls2'];
$dls03=$_POST['dls3'];
$dls04=$_POST['dls4'];
$dls05=$_POST['dls5'];
$gg=daddslashes($_POST['gongg']);
$ggs=daddslashes($_POST['gonggs']);
$user_reg=$_POST['user_reg'];
$reg_endtime1=$_POST['reg_endtime'];
$reg_cash1=$_POST['reg_cash'];
$user_reg_cash = $_POST['user_reg_cash'];
$sql="update `auth_config` set `gg`='$gg',`ggs`='$ggs',`activeok`='$ak',`regok`='$rk',`reg_cash`='$reg_cash1',`reg_endtime`='$reg_endtime1',`user_reg`='$user_reg',`user_reg_cash`='$user_reg_cash',`dl1`='$dl01',`dl2`='$dl02',`dl3`='$dl03',`dl4`='$dl04',`dl5`='$dl05',`dl0`='$dl00',`dls1`='$dls01',`dls2`='$dls02',`dls3`='$dls03',`dls4`='$dls04',`dls5`='$dls05',`dls0`='$dls00' where `id` = '1'";
if($DB->query($sql)){echo '<div class="box">恭喜亲成功保存所有信息设置</div>';}
else{echo'<div class="box">噢，保存信息失败,请稍后重新尝试.</div>';}
echo '<hr/><a href="./daili_config.php" class="btn btn-success">返回代理设置</a></div>';
exit;
}
?>				
      <form action="./daili_config.php" method="post" class="form-horizontal" role="form">
            	<input type="hidden" name="my" value="config"/>
				<div class="form-group has-success">
              <label class="col-sm-2 control-label">用户公告</label>
			<div class="col-sm-8"><textarea class="form-control" name="gonggs" rows="5" cols="50" required><?php echo $gonggs;?></textarea></div>
            </div>
			 <div class="hr-line-dashed"></div>
            	<div class="form-group has-error">
              <label class="col-sm-2 control-label">代理公告</label>
			<div class="col-sm-8"><textarea class="form-control" name="gongg" rows="5" cols="50" required><?php echo $gongg;?></textarea></div>
            </div>
			
			  <div class="hr-line-dashed"></div>
			<div class="form-group has-success">
			   <div class="col-sm-2"></div>
             	<label class="col-sm-1 control-label">注册赠送流量(M)</label>
				<div class="col-sm-1"><input type="text" class="form-control" name="reg_cash" value="<?php echo $rs['reg_cash'];?>"/></div>
				 <div class="col-sm-1"></div>
				<label class="col-sm-1 control-label">注册赠送天数</label>
				<div class="col-sm-1"><input type="text" class="form-control" name="reg_endtime" value="<?php echo $rs['reg_endtime'];?>"/></div>
				 <div class="col-sm-1"></div>
				<label class="col-sm-1 control-label">推荐赠送流量(M)</label>
				<div class="col-sm-1"><input type="text" class="form-control" name="user_reg_cash" value="<?php echo $rs['user_reg_cash'];?>"/></div>
			 </div>
			 <div class="hr-line-dashed"></div>
			 
			<div class="form-group has-warning">
              <label class="col-sm-2 control-label">代理注册</label>
                <div class="col-sm-2"><select name="rk" class="form-control">
                <?php 
					if($regok==1){
						echo '<option value="0">开放代理注册</option>
						<option value="1" selected="selected">关闭代理注册</option>';
					}else{echo '<option value="0" selected="selected">开放代理注册</option>
					<option value="1" >关闭代理注册</option>';}
                ?>
              </select></div>
              <label class="col-sm-1 control-label">普通用户注册</label>
                <div class="col-sm-2"><select name="ak" class="form-control">
                <?php 
          if($activeok==1){
            echo '<option value="0">开放用户注册</option>
			<option value="1" selected="selected">关闭用户注册</option>';
          }else{echo '<option value="0" selected="selected">开放用户注册</option>
		  <option value="1" >关闭用户注册</option>';}
                ?>
              </select></div>
            <label class="col-sm-1 control-label">账号注册方式</label>
                 <div class="col-sm-2"><select name="user_reg" class="form-control">
                  <?php 
					if($rs['user_reg']==1){
						echo ' <option value="1" selected="selected" >邮箱注册账号</option>
					<option value="0" >普通注册账号</option>';
					}else{echo '<option value="1">邮箱注册账号</option>
						<option value="0" selected="selected">普通注册账号</option>'; }
                  ?>
              </select></div>
			 </div>
			  <div class="hr-line-dashed"></div>
			<div class="form-group has-error">
             <label class="col-sm-2 control-label">青铜代理</label>
             	<label class="col-sm-1 control-label">（元/天）</label>
				<div class="col-sm-3"><input type="text" class="form-control" name="dl0" value="<?php echo $dl0;?>"/></div>
				<label class="col-sm-1 control-label">（元/G）</label>
				<div class="col-sm-3"><input type="text" class="form-control" name="dls0" value="<?php echo $dls0;?>"/></div>
			 </div>
			 
			  <div class="hr-line-dashed"></div>
			<div class="form-group has-success">
             <label class="col-sm-2 control-label">白银代理</label>
             	<label class="col-sm-1 control-label">（元/天）</label>
				<div class="col-sm-3"><input type="text" class="form-control" name="dl1" value="<?php echo $dl1;?>"/></div>
             	<label class="col-sm-1 control-label">（元/G）</label>
				<div class="col-sm-3"><input type="text" class="form-control" name="dls1" value="<?php echo $dls1;?>"/></div>
			 </div>
			 
			  <div class="hr-line-dashed"></div>
			<div class="form-group has-warning">
             <label class="col-sm-2 control-label">黄金代理</label>
             	<label class="col-sm-1 control-label">（元/天）</label>
				<div class="col-sm-3"><input type="text" class="form-control" name="dl2" value="<?php echo $dl2;?>"/></div>
				<label class="col-sm-1 control-label">（元/G）</label>
				<div class="col-sm-3"><input type="text" class="form-control" name="dls2" value="<?php echo $dls2;?>"/></div>
			 </div>
			 
			  <div class="hr-line-dashed"></div>
			<div class="form-group has-success">
             <label class="col-sm-2 control-label">铂金代理</label>
             	<label class="col-sm-1 control-label">（元/天）</label>
				<div class="col-sm-3"><input type="text" class="form-control" name="dl3" value="<?php echo $dl3;?>"/></div>
				<label class="col-sm-1 control-label">（元/G）</label>
				<div class="col-sm-3"><input type="text" class="form-control" name="dls3" value="<?php echo $dls3;?>"/></div>
			 </div>
			 
			  <div class="hr-line-dashed"></div>
			<div class="form-group has-error">
             <label class="col-sm-2 control-label">钻石代理</label>
             	<label class="col-sm-1 control-label">（元/天）</label>
				<div class="col-sm-3"><input type="text" class="form-control" name="dl4" value="<?php echo $dl4;?>"/></div>
				<label class="col-sm-1 control-label">（元/G）</label>
				<div class="col-sm-3"><input type="text" class="form-control" name="dls4" value="<?php echo $dls4;?>"/></div>
			 </div>
			 
			  <div class="hr-line-dashed"></div>
			<div class="form-group has-success">
             <label class="col-sm-2 control-label">王者代理</label>
             	<label class="col-sm-1 control-label">（元/天）</label>
				<div class="col-sm-3"><input type="text" class="form-control" name="dl5" value="<?php echo $dl5;?>"/></div>
				<label class="col-sm-1 control-label">（元/G）</label>
				<div class="col-sm-3"><input type="text" class="form-control" name="dls5" value="<?php echo $dls5;?>"/></div>
			 </div>
             <div class="hr-line-dashed"></div>
                            <div class="form-group">
                                <div class="col-sm-6 col-sm-offset-3">
                                    <button class="btn btn-primary" type="submit">保存当前设置</button>
                                </div>
                            </div>
          </form>
				
	    </div>				
            </div>
			  </div>
                        </div>
                    </div>
                </div>
    <!-- 自定义js -->
    <script src="../../assets/js/content.js?v=1.0.0"></script>

    </body>
</html>
