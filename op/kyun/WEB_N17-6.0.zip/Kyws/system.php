<?php
set_time_limit(0);
error_reporting(0);
//强制使用中国（上海）时区
date_default_timezone_set('Asia/Shanghai');
define('R',dirname( __FILE__));
define('RI',dirname( __FILE__).'/Core');
define('RT',dirname( __FILE__).'/Core/templates/tpl');
require(R.'/config.php');
require(RI.'/fun/html.fun.php');
require(RI.'/fun/function.fun.php');
require(RI.'/class/T.class.php');
require(RI.'/class/D.class.php');
require(RI.'/class/C.class.php');
require(RI.'/class/F.class.php');
require(RI.'/class/U.class.php');
require(RI.'/class/File.class.php');
require(RI.'/class/Page.class.php');
require(RI.'/class/Base.class.php');
require(RI.'/class/cInfo.class.php');
session_start();
//全局SQL注入
SqlBase::_deal();
//时区有问题请把下面的true改成false
if(true){
 define("SYSTEM_T",time());
}else{
  define("SYSTEM_T",time()+8*60*60);
}
$MAX_LIMIT = 100;
define("_MAX_LIMIT_",$MAX_LIMIT);

$t = explode(":",$_SERVER["HTTP_HOST"]);
$_SERVER["HTTP_HOST"] = $t[0];
function checkUsername($str)
	{
			$output='';
			$a=preg_match('/['.chr(0xa1).'-'.chr(0xff).']/', $str);
			$b=preg_match('/[0-9]/', $str);
			$c=preg_match('/[a-zA-Z]/', $str);
			if($a && $b && $c){
				$output='汉字数字英文的混合字符串';
			}elseif($a && $b && !$c){
				$output='汉字数字的混合字符串';
			}elseif($a && !$b && $c){
				$output='汉字英文的混合字符串';
			}elseif(!$a && $b && $c){
				$output='数字英文的混合字符串';
				return true;
			}elseif($a && !$b && !$c){
				$output='纯汉字';
				return true;
			}elseif(!$a && $b && !$c){
				$output='纯数字';
				return true;
			}elseif(!$a && !$b && $c){
				$output='纯英文';
				return true;
			}
			//return $output;
			return false;
}
	
function getvip() 
	{ 
      if (getenv("HTTP_CLIENT_IP")) 
       $ip = getenv("HTTP_CLIENT_IP"); 
      else if(getenv("HTTP_X_FORWARDED_FOR")) 
        $ip = getenv("HTTP_X_FORWARDED_FOR"); 
      else if(getenv("REMOTE_ADDR")) 
        $ip = getenv("REMOTE_ADDR"); 
      else $ip = "Unknow"; 
       return $ip; 
} 
	
function getAgent() 
	{ 
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    if (stripos($user_agent, "iPhone")!==false || stripos($user_agent, "iPad")!==false) { 
        $brand = 'iPhone';
    } else if (stripos($user_agent, "SAMSUNG")!==false || stripos($user_agent, "Galaxy")!==false || strpos($user_agent, "GT-")!==false || strpos($user_agent, "SCH-")!==false || strpos($user_agent, "SM-")!==false) {
        $brand = '三星';
    } else if (stripos($user_agent, "Huawei")!==false || stripos($user_agent, "Honor")!==false || stripos($user_agent, "H60-")!==false || stripos($user_agent, "H30-")!==false) {
        $brand = '华为';
    } else if (stripos($user_agent, "Lenovo")!==false) {
        $brand = '联想';
    } else if (strpos($user_agent, "MI-ONE")!==false || strpos($user_agent, "MI 1S")!==false || strpos($user_agent, "MI 2")!==false || strpos($user_agent, "MI 3")!==false || strpos($user_agent, "MI 4")!==false || strpos($user_agent, "MI-4")!==false) {
        $brand = '小米';
    } else if (strpos($user_agent, "HM NOTE")!==false || strpos($user_agent, "HM201")!==false) {
        $brand = '红米';
    } else if (stripos($user_agent, "Coolpad")!==false || strpos($user_agent, "8190Q")!==false || strpos($user_agent, "5910")!==false) {
        $brand = '酷派';
    } else if (stripos($user_agent, "ZTE")!==false || stripos($user_agent, "X9180")!==false || stripos($user_agent, "N9180")!==false || stripos($user_agent, "U9180")!==false) {
        $brand = '中兴';
    } else if (strpos($user_agent, "HTC")!==false || stripos($user_agent, "Desire")!==false) {
        $brand = 'HTC';
    } else if (stripos($user_agent, "vivo")!==false) {
        $brand = 'vivo';
    } else if (stripos($user_agent, "K-Touch")!==false) {
        $brand = '天语';
    } else if (stripos($user_agent, "Nubia")!==false || stripos($user_agent, "NX50")!==false || stripos($user_agent, "NX40")!==false) {
        $brand = '努比亚';
    } else if (strpos($user_agent, "M045")!==false || strpos($user_agent, "M032")!==false || strpos($user_agent, "M355")!==false) {
        $brand = '魅族';
    } else if (stripos($user_agent, "DOOV")!==false) {
        $brand = '朵唯';
    } else if (stripos($user_agent, "GFIVE")!==false) {
        $brand = '基伍';
    } else if (stripos($user_agent, "Gionee")!==false || strpos($user_agent, "GN")!==false) {
        $brand = '金立';
    } else if (stripos($user_agent, "HS-U")!==false || stripos($user_agent, "HS-E")!==false) {
        $brand = '海信';
    } else if (stripos($user_agent, "Nokia")!==false) {
        $brand = '诺基亚';
	} else if (stripos($user_agent, "ONE")!==false) {
        $brand = '一加';
	} else if (stripos($user_agent, "Meitu")!==false || stripos($user_agent, "MeituM4")!==false) {
        $brand = '美图';
	} else if (stripos($user_agent, "ASUS_Z00ADB")!==false || stripos($user_agent, "ASUS")!==false) {
        $brand = '华硕';
	} else if (stripos($user_agent, "OPPO")!==false || strpos($user_agent, "X9007")!==false || strpos($user_agent, "X907")!==false || strpos($user_agent, "X909")!==false || strpos($user_agent, "R831S")!==false || strpos($user_agent, "R827T")!==false || strpos($user_agent, "R821T")!==false || strpos($user_agent, "R811")!==false || strpos($user_agent, "R2017")!==false) {
        $brand = 'OPPO';
	} else if (stripos($user_agent, "360")!==false) {
        $brand = '360';
    } else {
        $brand = '安卓';
    }
 return $brand; 
} 