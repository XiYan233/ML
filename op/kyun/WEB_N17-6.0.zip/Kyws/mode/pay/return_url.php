<html>
    <head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
     <title>支付即时到账交易接口</title>
	<link href="http://apps.bdimg.com/libs/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet">
	</head>
    <body>
<?php
/* * 
 * 功能：支付页面跳转同步通知页面
 * 说明：
 * 以下代码只是为了方便商户测试而提供的样例代码，商户可以根据自己网站的需要，按照技术文档编写,并非一定要使用该代码。
 * 该代码仅供学习和研究支付宝接口使用，只是提供一个参考。
 */
require_once("../../../Data/api.inc.php");
$KyPayHost = $_SERVER['HTTP_REFERER'];
if($KyPayHost != 'http://kypay.top/pay/return_url.php'){
  echo '<div style="margin:10px 10px;"><div class="alert alert-warning"><h4>Sorry,The current address is not from KyPay.</h4></div></div>';
  exit;	
}
 //首次验证信息
if($_GET['out_trade_no'] && $_GET['trade_no'] && $_GET['trade_status'] && $_GET['type']) { 
////////////////////////////////////////////////////////////////////////////////////////////////
    //检查订单号函数
    function is_base64($str){ 
     if($str==base64_encode(base64_decode($str))){ 
        return true; 
    }else{ 
        return false; 
      } 
    }
		
	//检测商户订单号	
    $checkA=is_base64($_GET['out_trade_no']);
	
	//商户订单号
    if(!$checkA){ 
     echo '<div style="margin:10px 10px;"><div class="alert alert-warning"><h4>没有找到这个订单号哦</h4></div></div>';exit;
    }else{
	 $out_trade_no = base64_decode($_GET['out_trade_no']);
	}
	//检测支付宝交易号
	$checkB=is_base64($_GET['trade_no']);
	
    //支付宝交易号	
    if(!$checkB){ 
     echo '<div style="margin:10px 10px;"><div class="alert alert-warning"><h4>没有找到这个订单号哦</h4></div></div>';exit;
    }else{
	$trade_no = base64_decode($_GET['trade_no']);	
	}
	
	//交易状态
	$trade_status = $_GET['trade_status'];

	//支付方式
	$type = $_GET['type'];
    
if($_GET['trade_status'] == 'TRADE_SUCCESS') {
//检测该订单是否处理过
$sqlA = "SELECT * FROM `ky_buy` where `trade`='{$out_trade_no}'";

if(!$check = $DB->get_row($sqlA)){
echo '<div style="margin:10px 10px;"><div class="alert alert-warning"><h4>没有该订单号的信息哦</h4></div></div>';
exit;
}elseif($check['i'] == '1'){
echo '<div style="margin:10px 10px;"><div class="alert alert-warning"><h4>该订单号已经处理过了哦</h4></div></div>';
exit;	
}
//处理交易成功信息 
$sqlB = "update `ky_buy` set `i`='1',`trade`='{$trade_no}' where `trade`='{$out_trade_no}'";
if($DB->query($sqlB)){
	$rs=$DB->get_row("SELECT * FROM `ky_buy` where `trade`='{$trade_no}'");
    $u = $rs['user'];
    $tc = $rs['tc'];
	$dlid = $rs['dlid'];
	$buy = $DB->get_row("SELECT * FROM `ky_tc` where `name`='{$tc}' && dlid='{$dlid}'");
	$mb = $buy['G']*1024*1024*1024;
	$tian = $buy['tian'];
	$endtime = time()+3600*24*$tian;
	$res=$DB->get_row("SELECT * FROM `openvpn` where `iuser`='{$u}'");
	$sqlC="update `openvpn` set `isent`='0',`irecv`='0',`maxll`='{$mb}',`i`='1',`starttime`='".time()."',`endtime`='{$endtime}',`dlid`='{$dlid}',`tian`='{$tian}' where `iuser`='{$u}'";
if($DB->query($sqlC)){
	exit("<script language='javascript'>alert('亲，恭喜你购买流量成功！');window.location.href='../../api.php?act=more&dlapp=".$dlid."&username=".$res['iuser']."&password=".$res['pass']."';</script>");	
}else{
	exit("<script language='javascript'>alert('购买流量失败，请联系客服！');window.location.href='../../api.php?act=help&dlapp=".$dlid."&username=".$res['iuser']."&password=".$res['pass']."';</script>");		
}
	//——请根据您的业务逻辑来编写程序（以上代码仅作参考）
}}}else {
    //验证失败
    echo '<div style="margin:10px 10px;"><div class="alert alert-warning"><h3>未付款成功哦</h3></div></div>';
}
////////////////////////////////////////////////////////////////////////////////////////////////
?>
    </body>
</html>