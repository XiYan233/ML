<?php
	require("system.php");
	$id = $_POST['id'];
	$u = $_POST["username"];
	$p = $_POST["password"];
	$f = $_POST["note"];
		$db = db(_openvpn_);
		$info = $db->where(array(_iuser_=>$u,_ipass_=>$p))->find();
		if($info){
			if("".$info[_i_] == "1"){
			$line = db('line')->where(array('id'=>$id))->find();
            $zs=db("ky_zs")->where(array())->find();
            $fwq=db("ky_fz")->where(array("id"=>$f))->find();
            $SETIP=$fwq["ipport"];			
			$content = $line['content'];
			$content = preg_replace("/\[ip\]/is",$SETIP,$content);
            $content = preg_replace("/\[C证书\]/is",html_decode($zs["ca"]),$content);
            $content = preg_replace("/\[T证书\]/is",html_decode($zs["tls"]),$content);			
			db(_openvpn_)->where(array(_iuser_=>$u))->update(array('line_id'=>$id));
			$data = array(
				'status'=>'success',
				'name'=>$line['name'],
				'type'=>$line['type'],
				'content'=>base64_encode($content)
			);
			die(json_encode($data));
			}else{
				$data = array(
				'status'=>'error',
				'msg'=>"您的身份信息处于未激活状态 不可安装"
				);
				die(json_encode($data));
			}
		}else{
			$data = array(
				'status'=>'error',
				'msg'=>"您的身份信息未能经过验证"
			);
			die(json_encode($data));
		}