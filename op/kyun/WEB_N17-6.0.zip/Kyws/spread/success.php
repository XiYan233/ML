<?php 
header('Content-Type: text/html; charset=UTF-8');
?><html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<meta charset="utf-8"> 
<!-- 新 Bootstrap 核心 CSS 文件 -->
<link href="http://apps.bdimg.com/libs/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet">

<!-- 可选的Bootstrap主题文件（一般不使用） -->
<script src="http://apps.bdimg.com/libs/bootstrap/3.3.0/css/bootstrap-theme.min.css"></script>

<!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
<script src="http://apps.bdimg.com/libs/jquery/2.0.0/jquery.min.js"></script>

<!-- 最新的 Bootstrap 核心 JavaScript 文件 -->
<script src="http://apps.bdimg.com/libs/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<title>快云流量账号注册</title>
<style>
body,html{
	background:#efefef;
	padding:0px;
	margin:0px;
	overflow-x:hidden;
}
.main{
	margin:10px;
}
.list-group-item a{
	display:block;
}
.label-t{
	margin-bottom:20px;
}
.line{
	height:1px;
	background:#ccc;
}
.btn{
	border-radius: 0px;

}
</style></head>
<body>
<style>
.main{
	background:#fff;
	padding:15px;
	border-right:1px solid #ccc;
	border-bottom:1px solid #ccc;
	border-top:1px solid #dfdfdf;
	border-left:1px solid #dfdfdf;
}
</style>
<div class="main">
<div style="height:50px"></div>
    <span class="glyphicon glyphicon-ok" style="color: rgb(159, 219, 60); font-size: 38px;"> 注册成功</span>
	<hr>
	<div class="alert alert-success">
		恭喜您，您已经成功的完成了账号申请！系统已经赠送你相应的流量，赶快下载APP登录使用吧！
	</div>

    <button type="submit" class="btn btn-success btn-block" onclick="sysC()" >立 即 下 载</button> <br>
</div>

<script>
function sysC(){
window.location.href="<?php echo 'http://'.$_SERVER['SERVER_NAME'].':'.$_SERVER["SERVER_PORT"].'/user/app';?>";
}
$(function() { 
        $('#myModal').modal({ 
            keyboard: true 
        }) 
    }); 
</script>