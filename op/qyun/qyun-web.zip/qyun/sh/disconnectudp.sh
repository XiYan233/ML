#!/bin/sh
#集群和云数据库请不要改此文件直接修改同目录里的peizhi.cfg文件
source /etc/openvpn/peizhi.cfg
user=$common_name

mysql -h$localhost -u$root -p$mima -e "use ov;SELECT isent FROM openvpn WHERE iuser='$user';">/etc/openvpn/uaddlogs.txt
sleep 1
mysql -h$localhost -u$root -p$mima -e "use ov;SELECT irecv FROM openvpn WHERE iuser='$user';">/etc/openvpn/uaddlogr.txt
sleep 1
sent=$(sed -n 2p /etc/openvpn/uaddlogs.txt)
recv=$(sed -n 2p /etc/openvpn/uaddlogr.txt)

#rm -rf addlogs.txt
#rm -rf addlogr.txt

sent=$[$sent+$bytes_sent]
recv=$[$recv+$bytes_received]
mysql -h$localhost -u$root -p$mima -e "use ov;UPDATE openvpn SET isent = '$sent' WHERE iuser='$user';"
sleep 1
mysql -h$localhost -u$root -p$mima -e "use ov;UPDATE openvpn SET irecv = '$recv' WHERE iuser='$user';"



#青云官网：www.qyunl.com
