<?php
return array (
  'ver' => '6.2',
  'release' => '2017-03-02',
  'vername' => '青云VPN',
);
?>