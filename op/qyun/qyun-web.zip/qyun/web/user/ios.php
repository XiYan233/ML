<?php
?>
<?php 
$mod = 'blank';
include "../api.inc.php";
$u = daddslashes($_GET['user']);
$p = daddslashes($_GET['pass']);
$res = $DB->get_row("SELECT * FROM `openvpn` where `iuser`='{$u}' && `pass`='{$p}' limit 1");
if (!$res) {
    exit("<script language='javascript'>alert('未正确登录，或用户名或密码不正确！');window.location.href='/user/login.php';</script>");
}
$daili_info = $DB->get_row("SELECT * FROM openvpn where `iuser`='{$u}\n'");
$daili_info_id = $daili_info['dlid'];
if ($daili_info_id) {
} else {
    $daili_info_id = 0;
}
if ($daili_info_id) {
    $config_dl = $DB->get_row("SELECT * FROM auth_daili WHERE id='{$daili_info_id}' limit 1");
    $config_name = $config_dl['name'];
    $config_qq = $config_dl['qq'];
    $config_tel = $config_dl['tel'];
    $config_buy = $config_dl['buy'];
    $config_buy2 = $config_dl['buy2'];
} else {
    $rs = $DB->get_row("SELECT * FROM website");
    $config_name = $rs['title'];
    $config_qq = $rs['qq'];
    $config_tel = $rs['tel'];
    $rs2 = $DB->get_row("SELECT * FROM auth_config");
    $config_buy = $rs2['shopUrl'];
    $config_buy2 = $rs2['shopCode'];
}
?>
<!DOCTYPE html>
<html lang="en">
<?php 
include '../assets/head2.php';
?>
<body class="page-body">
	
	<div class="page-container">
			
	<?php 
include 'nav.php';
?>
		
		<div class="main-content">
					
			<?php 
include 'info.php';
?>
			
			<!-- Xenon Counter Widget -->
			<div class="row">
                                           <div id="wap" class="col-sm-12">
                                           <div class="alert alert-white">
                                               <button type="button" class="close" data-dismiss="alert">
                                                   <span aria-hidden="true">×</span>
                                                   <span class="sr-only">Close</span>
                                               </button>
                                               
                                               <strong>部分线路需要WAP模式：</strong> 安卓从网络设置APN接入点切换，苹果用户使用IOS系统自带的Safari浏览器打开下方链接，会自动下载描述文件，点击安装，然后重启手机。<hr>

                                               <div class="btn-group btn-group-justified">                 
                                                   <a href="ios/CMWAP.mobileconfig" type="button" class="btn btn-white btn-sm">移动WAP</a>
                                                   <a href="ios/3GWAP.mobileconfig" type="button" class="btn btn-white btn-sm">联通WAP</a>
                                                   <a href="ios/CTWAP.mobileconfig" type="button" class="btn btn-white btn-sm">电信WAP</a>
                                               </div>
                                           </div>
                                           </div>

		                   <div id="addtype_list" class="col-sm-12">

	                                 <?php 
if ($down == 0) {
    ?>
			         <ul class="nav nav-tabs nav-tabs-justified">
			           <li class="active">
			             <a href="#home-3" data-toggle="tab">
			               <span class="visible-xs">移动</span>
			               <span class="hidden-xs">移动</span>
			             </a>
			           </li>
			           <li>
			             <a href="#profile-3" data-toggle="tab">
			               <span class="visible-xs">联通</span>
			               <span class="hidden-xs">联通</span>
			             </a>
			           </li>
			           <li>
			             <a href="#messages-3" data-toggle="tab">
			               <span class="visible-xs">电信</span>
			               <span class="hidden-xs">电信</span>
			             </a>
			           </li>
			         </ul>
         <div class="tab-content">
           <div class="tab-pane active" id="home-3">
             
           <table class="table">
             <tbody>
<?php 
    $res = $DB->query("SELECT * FROM `qyun_article` WHERE  `category_id` = 1 ");
    while ($open = $DB->fetch($res)) {
        echo '
               <tr>
                 <td class="middle-align">';
        echo $open['title'];
        echo '</td>
                 <td style="text-align: right;">
                   <a href="/admin/down.php?id=';
        echo $open['id'];
        echo '" class="btn btn-turquoise btn-single btn-sm" onclick="return confirm(\'请您使用OpenVPN打开该文件\');">安装</a>
                 </td>
               </tr>';
    }
    ?>
             </tbody>
           </table>
             
           </div>
           <div class="tab-pane" id="profile-3">
             
           <table class="table">
             <tbody>
<?php 
    $res = $DB->query("SELECT * FROM `qyun_article` WHERE `category_id` = 2 ");
    while ($open = $DB->fetch($res)) {
        echo '
               <tr>
                 <td class="middle-align">';
        echo $open['title'];
        echo '</td>
                 <td style="text-align: right;">
                   <a href="/admin/down.php?id=';
        echo $open['id'];
        echo '" class="btn btn-turquoise btn-single btn-sm" onclick="return confirm(\'请您使用OpenVPN打开该文件\');">安装</a>
                 </td>
               </tr>';
    }
    ?>
             </tbody>
           </table>
               
           </div>
           <div class="tab-pane" id="messages-3">
             
           <table class="table">
             <tbody>
<?php 
    $res = $DB->query("SELECT * FROM `qyun_article` WHERE  `category_id` = 3 ");
    while ($open = $DB->fetch($res)) {
        echo '
               <tr>
                 <td class="middle-align">';
        echo $open['title'];
        echo '</td>
                 <td style="text-align: right;">
                   <a href="/admin/down.php?id=';
        echo $open['id'];
        echo '" class="btn btn-turquoise btn-single btn-sm" onclick="return confirm(\'请您使用OpenVPN打开该文件\');">安装</a>
                 </td>
               </tr>';
    }
    ?>
             </tbody>
           </table>
         
           </div>
           
         </div>
	                           <?php 
} else {
    echo '<div class="alert alert-white">
										<button type="button" class="close" data-dismiss="alert">
											<span aria-hidden="true">×</span>
											<span class="sr-only">Close</span>
										</button>
										
										<strong>您好，</strong>暂无苹果线路可下载！
									</div>';
}
?>

		                   </div>

			</div>

			<!-- Main Footer -->
			<?php 
include "../assets/copy2.php";
?>
		</div>
		
	</div>
<link rel="stylesheet" href="app/css/app.css"/>
   <div id="weixin-tip"><p><img src="app/img/live_weixin.png" alt="微信打开"/><span id="close" title="关闭" class="close">×</span></p></div>
   <script type="text/javascript">
   var is_weixin = (function() {
       var ua = navigator.userAgent.toLowerCase();
       if (ua.match(/MicroMessenger/i) == "micromessenger") {
           return true;
       } else {
           return false;
       }
   })();
   window.onload = function(){
       var winHeight = typeof window.innerHeight != 'undefined' ? window.innerHeight : document.documentElement.clientHeight;
       var btn = document.getElementById('J_weixin');
       var tip = document.getElementById('weixin-tip');
       var close = document.getElementById('close');
       if(is_weixin){
               tip.style.height = winHeight + 'px';
               tip.style.display = 'block';
               return false;
       }
   }
   

   </script>
<?php 
include "js.php";
?>

</body>
</html><?php 