<?php
?>
<?php 
$mod = 'blank';
include "../api.inc.php";
$title = '用户注册';
$dlconfig = $DB->get_row("SELECT * FROM auth_config WHERE 1");
$tj_user = daddslashes($_REQUEST['tj_user']);
$dl = daddslashes($_REQUEST['dl']);
if ($dl) {
} else {
    $dl = '0';
}
if ($_POST['user'] && $_POST['pass']) {
    $user = daddslashes($_POST['user']);
    $pass = daddslashes($_POST['pass']);
    $dlid = daddslashes($_POST['dlid']);
    $fwq = daddslashes($_POST['fwq']);
    if ($fwq) {
    } else {
        $fwq = '0';
    }
    $verifycode = daddslashes($_POST['verifycode']);
    $row = $DB->get_row("SELECT * FROM `openvpn` WHERE `iuser`='{$user}' limit 1");
    $i = 0;
    $b_time = time();
    $rs = $DB->get_row("SELECT * FROM auth_config");
    $reg_cash_con = $rs['reg_cash'];
    $user_endtime_con = $rs['user_endtime'];
    if ($reg_cash_con > 0) {
        $i = 1;
        $a = date('Y-m-d');
        $a_time = strtotime($a);
        $b_time = strtotime('+' . $user_endtime_con . ' Day', $a_time);
    }
    $tj_user = daddslashes($_REQUEST['tj_user_c']);
    $zrs = $DB->get_row("SELECT * FROM auth_config");
    $user_cash_con = round($zrs['user_cash'] / 1024 / 1024);
    if ($tj_user) {
        $tj_ok = 1;
    }
    if (!is_username($user)) {
        exit("<script language='javascript'>alert('用户名只能是2~20位的字母数字！');history.go(-1);</script>");
    } elseif ($row) {
        exit("<script language='javascript'>alert('用户名已被使用！');history.go(-1);</script>");
    } elseif (!$verifycode || $verifycode != $_SESSION['verifycode']) {
        exit("<script language='javascript'>alert('验证码不正确！');history.go(-1);</script>");
    } else {
        $DB->query("insert `openvpn`(`iuser`,`pass`,`isent`,`irecv`,`maxll`,`i`,`starttime`,`endtime`,`fwqid`,`tj_user`,`tj_ok`,`dlid`) values('{$user}','{$pass}',0,0,'{$reg_cash_con}','{$i}','" . time() . "','" . $b_time . "','" . $fwq . "','" . $tj_user . "','" . $tj_ok . "','" . $dlid . "')");
        $row = $DB->get_row("SELECT * FROM `openvpn` WHERE `iuser`='{$user}' limit 1");
        if ($row['id']) {
            unset($_SESSION['verifycode']);
            exit("<script language='javascript'>alert('注册成功，返回登录！');window.location.href='/user/login.php';</script>");
        } else {
            exit("<script language='javascript'>alert('注册失败，请联系管理员！');history.go(-1);</script>");
        }
    }
}
$fwqlist = $DB->query("SELECT * FROM auth_fwq");
?>
<!DOCTYPE html>
<html lang="en">
<?php 
include '../assets/head2.php';
?>
<body class="page-body login-page login-light">

	
	<div class="login-container">
	
		<div class="row">
		
			<div class="col-sm-6 col-sm-offset-3">
			
				<script type="text/javascript">
					jQuery(document).ready(function($)
					{
						// Reveal Login form
						setTimeout(function(){ $(".fade-in-effect").addClass('in'); }, 1);
						
						
						// Validation and Ajax action
						$("form#login").validate({
							rules: {
								user: {
									required: true
								},
								
								pass: {
									required: true
								},
								
								verifycode: {
									required: true
								}
							},
							
							messages: {
								user: {
									required: '此为必填项！'
								},
								
								pass: {
									required: '此为必填项！'
								},
								
								verifycode: {
									required: '请填写！'
								}
							},
							
						});
						
						// Set Form focus
						$("form#login .form-group:has(.form-control):first .form-control").focus();
					});
				</script>
				
				<!-- Errors container -->
				<div class="errors-container">
				
									
				</div>
				
				<!-- Add class "fade-in-effect" for login form effect -->
				<form action="./reg.php?tj_user_c=<?php 
echo $tj_user;
?>" method="post" role="form" id="login" class="login-form fade-in-effect">
					
					<?php 
$rs = $DB->get_row("SELECT * FROM website");
$logo = $rs['logo'];
?>
					<div class="login-header">
						<img src="<?php 
echo $logo;
?>" alt="" width="80" />
						<span>您身边的流量领导者!</span>
					</div>
	
					
					<div class="form-group">
						<label class="control-label" for="user">请输入您的帐号</label>
						<input type="text" class="form-control" name="user" id="user" autocomplete="off" />
					</div>
					
					<div class="form-group">
						<label class="control-label" for="pass">请输入您的密码</label>
						<input type="password" class="form-control" name="pass" id="pass" autocomplete="off" />
					</div>

					<input type="text" value="<?php 
echo $dl;
?>" name="dlid" class="hide" />

					<div class="form-group">
						<label class="control-label">Simple select</label>
						
						<script type="text/javascript">
							jQuery(document).ready(function($)
							{
								$("#sboxit-1").selectBoxIt().on('open', function()
								{
									// Adding Custom Scrollbar
									$(this).data('selectBoxSelectBoxIt').list.perfectScrollbar();
								});
							});
						</script>
						
						<select class="form-control" id="sboxit-1" name="fwq">
							<?php 
while ($v = $DB->fetch($fwqlist)) {
    ?>
							<option value="<?php 
    echo $v['id'];
    ?>"><?php 
    echo $v['name'];
    ?></option>
							<?php 
}
?>
						</select>
							
					</div>

					<div class="form-group">
		            	<label class="control-label" for="verifycode">验证码</label>
		            	<input type="text" id="verifycode" name="verifycode" class="form-control" placeholder="验证码" required="required" style="max-width: 65%;display:inline-block;"/>&nbsp;<img title="点击刷新" src="../verifycode.php" onclick="this.src='../verifycode.php?'+Math.random();" style="max-height:32px;vertical-align:middle;" class="img-rounded">
		            </div>
					
					<div class="form-group">
						<button type="submit" class="btn btn-secondary  btn-block text-center">
							<i class="fa-lock"></i>
							立即注册
						</button>
					</div>
					
				</form>
				
				<!-- External login -->
				<div class="external-login">
					<a href="login.php" class="btn btn-info text-center">
						<i class="fa-edit"></i>
						已经有账号？立即登录吧！
					</a>
					
					<!-- 
					<a href="#" class="twitter">
						<i class="fa-twitter"></i>
						Login with Twitter
					</a>
					
					<a href="#" class="gplus">
						<i class="fa-google-plus"></i>
						Login with Google Plus
					</a>
					 -->
				</div>
				
			</div>
			
		</div>
		
	</div>



	<!-- Bottom Scripts -->
	<script src="../assets/js/bootstrap.min.js"></script>
	<script src="../assets/js/TweenMax.min.js"></script>
	<script src="../assets/js/resizeable.js"></script>
	<script src="../assets/js/joinable.js"></script>
	<script src="../assets/js/xenon-api.js"></script>
	<script src="../assets/js/xenon-toggles.js"></script>
	<script src="../assets/js/jquery-validate/jquery.validate.min.js"></script>
	<script src="../assets/js/toastr/toastr.min.js"></script>

	<script src="../assets/js/select2/select2.min.js"></script>
	<script src="../assets/js/jquery-ui/jquery-ui.min.js"></script>
	<script src="../assets/js/selectboxit/jquery.selectBoxIt.min.js"></script>

	<!-- JavaScripts initializations and stuff -->
	<script src="../assets/js/xenon-custom.js"></script>

</body>
</html><?php 