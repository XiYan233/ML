
<?php
?>
<?php 
$mod = 'blank';
include "../api.inc.php";
$u = daddslashes($_GET['user']);
$p = daddslashes($_GET['pass']);
$res = $DB->get_row("SELECT * FROM `openvpn` where `iuser`='{$u}' && `pass`='{$p}' limit 1");
if (!$res) {
    exit("<script language='javascript'>alert('未正确登录，或用户名或密码不正确！');window.location.href='/user/login.php';</script>");
}
$tian = $res['tian'];
$web_dl = $res['dlid'];
if ($tian > 0) {
    $a = date('Y-m-d');
    $a_time = strtotime($a);
    $b_time = strtotime('+' . $tian . ' Day', $a_time);
    $DB->query("update `openvpn` set `endtime`='{$b_time}',`i` ='1',`tian` ='0' where `iuser`='{$u}'");
    echo "<script language='javascript'>alert('您好，这是第一次登录，帐号已激活，使用天数为" . $tian . "天！');window.location.reload();</script>";
}
if ($_POST['km']) {
    $km = daddslashes($_POST['km']);
    $myrow = $DB->get_row("select * from auth_kms where kind=1 and km='{$km}' limit 1");
    if (!$myrow) {
        exit("<script language='javascript'>alert('此激活码不存在');history.go(-1);</script>");
    } elseif ($myrow['isuse'] == 1) {
        exit("<script language='javascript'>alert('此激活码已被使用');history.go(-1);</script>");
    } else {
        $duetime = time() + $myrow['value'] * 24 * 60 * 60;
        $addll = $myrow['values'] * 1024 * 1024 * 1024;
        if ($res['endtime'] < time()) {
            $sql = "update `openvpn` set `isent`='0',`irecv`='0',`maxll`='{$addll}',`endtime`='{$duetime}',`dlid`='{$myrow['daili']}',`i`='1' where `iuser`='{$u}' && `pass`='{$p}'";
            if ($DB->query($sql)) {
                $DB->query("update `auth_kms` set `isuse` ='1',`user` ='{$u}',`usetime` ='{$date}' where `id`='{$myrow['id']}'");
                wlog('账号激活', '用户' . $u . '使用激活码' . $km . '开通账号[' . $date . ']');
                $zrs = $DB->get_row("SELECT * FROM openvpn where `iuser`='{$u}'");
                $tj_user = $zrs['tj_user'];
                $tj_ok = $zrs['tj_ok'];
                $zzrs = $DB->get_row("SELECT * FROM auth_config");
                $user_cash_con = $zzrs['user_cash'];
                if ($tj_ok > 0) {
                    $tjr = $DB->get_row("SELECT * FROM openvpn where `iuser`='{$tj_user}'");
                    $tj_new_maxll = round($tjr['maxll'] + $user_cash_con);
                    $DB->query("update `openvpn` set `maxll`='{$tj_new_maxll}', `i`='1' where `iuser`='{$tj_user}'");
                    $DB->query("update `openvpn` set `tj_ok` ='0' where `iuser`='{$u}'");
                    echo "<script language='javascript'>alert('您的推荐人：" . $tj_user . "，获得" . round($user_cash_con / 1024 / 1024) . "MB流量！');</script>";
                }
                exit("<script language='javascript'>alert('开通成功！');history.go(-1);</script>");
            } else {
                exit("<script language='javascript'>alert('开通失败！');history.go(-1);</script>");
            }
        } else {
            $sql = "update `openvpn` set `maxll`='{$addll}',`endtime`='{$duetime}',`dlid`='{$myrow['daili']}',`i`='1' where `iuser`='{$u}' && `pass`='{$p}'";
            if ($DB->query($sql)) {
                $DB->query("update `auth_kms` set `isuse` ='1',`user` ='{$u}',`usetime` ='{$date}' where `id`='{$myrow['id']}'");
                wlog('账号充值', '用户' . $u . '使用激活码' . $km . '续费账号[' . $date . ']');
                $zrs = $DB->get_row("SELECT * FROM openvpn where `iuser`='{$u}'");
                $tj_user = $zrs['tj_user'];
                $tj_ok = $zrs['tj_ok'];
                $zzrs = $DB->get_row("SELECT * FROM auth_config");
                $user_cash_con = $zzrs['user_cash'];
                if ($tj_ok > 0) {
                    $tjr = $DB->get_row("SELECT * FROM openvpn where `iuser`='{$tj_user}'");
                    $tj_new_maxll = round($tjr['maxll'] + $user_cash_con);
                    $DB->query("update `openvpn` set `maxll`='{$tj_new_maxll}', `i`='1' where `iuser`='{$tj_user}'");
                    $DB->query("update `openvpn` set `tj_ok` ='0' where `iuser`='{$u}'");
                    echo "<script language='javascript'>alert('您的推荐人：" . $tj_user . "，获得" . round($user_cash_con / 1024 / 1024) . "MB流量！');</script>";
                }
                exit("<script language='javascript'>alert('续费成功！');history.go(-1);</script>");
            } else {
                exit("<script language='javascript'>alert('续费失败！');history.go(-1);</script>");
            }
        }
    }
} elseif ($_POST['newpass']) {
    $newpass = daddslashes($_POST['newpass']);
    if ($DB->query("update `openvpn` set `pass` ='{$newpass}' where `iuser`='{$u}' && `pass`='{$p}' limit 1")) {
        exit("<script language='javascript'>alert('密码修改成功！');history.go(-1);</script>");
    } else {
        exit("<script language='javascript'>alert('密码修改失败！');history.go(-1);</script>");
    }
}
$qrs = $DB->get_row("SELECT * FROM auth_config");
$user_cash_con = $qrs['user_cash'];
$qian_con = $qrs['qian'];
if ($_POST['qiandao']) {
    $qian_num_con = 1;
    $qrs2 = $DB->get_row("SELECT * FROM openvpn where `iuser`='{$u}'");
    $now_time = date("Y-m-d");
    $qian_date = $qrs2['qian_date'];
    $qian_num = $qrs2['qian_num'];
    if ($qian_date != $now_time) {
        $new_maxll = round($qrs2['maxll'] + $qian_con);
        $qian_num = round($qrs2['qian_num'] + $qian_num_con);
        $DB->query("update `openvpn` set `maxll`='{$new_maxll}',`qian_date` ='{$now_time}',`qian_num` ='{$qian_num}' where `iuser`='{$u}'");
        echo "<script language='javascript'>alert('签到成功，新增" . round($qian_con / 1024 / 1024) . "MB流量！');</script>";
    } else {
        echo "<script language='javascript'>alert('您今天已经签到了！');</script>";
    }
} else {
}
$title = '用户中心';
$config = $DB->get_row("SELECT * FROM auth_config");
$gonggao = $config['ggs'];
$daili_info = $DB->get_row("SELECT * FROM openvpn where `iuser`='{$u}'");
$daili_info_id = $daili_info['dlid'];
if ($daili_info_id) {
    $config_dl = $DB->get_row("SELECT * FROM auth_daili WHERE id='{$daili_info_id}' limit 1");
    $config_name = $config_dl['name'];
    $config_qq = $config_dl['qq'];
    $config_tel = $config_dl['tel'];
    $config_buy = $config_dl['buy'];
    $config_buy2 = $config_dl['buy2'];
} else {
    $rs = $DB->get_row("SELECT * FROM website");
    $config_name = $rs['title'];
    $config_qq = $rs['qq'];
    $config_tel = $rs['tel'];
    $rs2 = $DB->get_row("SELECT * FROM auth_config");
    $config_buy = $rs2['shopUrl'];
    $config_buy2 = $rs2['shopCode'];
}
$alpay = $DB->get_row("SELECT * FROM alipay");
$alpay_on = $alpay['partner'];
?>
<!DOCTYPE html>
<html lang="en">
<?php 
include '../assets/head2.php';
?>
<body class="page-body">
	
	<div class="page-container"><!-- add class "sidebar-collapsed" to close sidebar by default, "chat-visible" to make chat appear always -->
			
	<?php 
include 'nav.php';
?>
		
		<div class="main-content">
					
			<?php 
include 'info.php';
?>
			
			<!-- Xenon Counter Widget -->
			<div class="row">
				<div class="col-sm-6">
					
					<div class="xe-widget xe-counter" data-count=".num" data-from="0" data-to="<?php 
echo round($res['maxll'] / 1024 / 1024);
?>" data-suffix="M" data-duration="2">
						<div class="xe-icon">
							<i class="linecons-cloud"></i>
						</div>
						<div class="xe-label">
							<strong class="num">0</strong>
							<span>总计流量</span>
						</div>
					</div>
					
				</div>
				<div class="col-sm-6">
					
					<div class="xe-widget xe-counter xe-counter-blue" data-count=".num" data-from="1" data-to="<?php 
echo round(($res['maxll'] - $res['isent'] - $res['irecv']) / 1024 / 1024);
?>" data-suffix="M" data-duration="3" data-easing="false">
						<div class="xe-icon">
							<i class="linecons-database"></i>
						</div>
						<div class="xe-label">
							<strong class="num">0</strong>
							<span>剩余流量</span>
						</div>
					</div>
				
				</div>
			</div>
			
			
			<!-- Xenon Block Counter Widget -->
			<div class="row">
				<div class="col-sm-6">
				
					<div class="xe-widget xe-counter-block" data-count=".num" data-from="0" data-to="<?php 
echo round(($res['maxll'] - $res['isent'] - $res['irecv']) / $res['maxll'] * 100);
?>" data-suffix="%" data-duration="2">
						<div class="xe-upper">
							
							<div class="xe-icon">
								<i class="linecons-params"></i>
							</div>
							<div class="xe-label">
								<strong class="num">0.0%</strong>
								<span>流量剩余比例</span>
							</div>
							
						</div>
						<div class="xe-lower">
							<div class="border"></div>
							
							<span>已经上传：<?php 
echo round($res['irecv'] / 1024 / 1024);
?>M</span>
							<strong>已经下载：<?php 
echo round($res['isent'] / 1024 / 1024);
?>M</strong>
						</div>
					</div>
					
				</div>

				<div class="col-sm-6">
	                            <?php 
date_default_timezone_set('Asia/Hong_Kong');
$startDate = date('Y-m-d', $res['starttime']);
$endDate = date('Y-m-d', $res['endtime']);
$startDateStr = strtotime($startDate);
$endtDateStr = strtotime($endDate);
$total = $endtDateStr - $startDateStr;
$now = strtotime(date('Y-m-d'));
$remain = $endtDateStr - $now;
?>
			                    <div class='xe-widget xe-counter-block xe-counter-block-purple' data-count='.num' data-from='0' data-to='<?php 
echo $remain / (3600 * 24);
?>' data-suffix='天' data-duration='3'>
			                        <div class='xe-upper'>
			                            
			                            <div class='xe-icon'>
			                                <i class='linecons-calendar'></i>
			                            </div>
			                            <div class='xe-label'>
			                                <strong class='num'>0</strong>
			                                <span>剩余使用时间</span>
			                            </div>
			                            
			                        </div>
			                        <div class='xe-lower'>
			                            <div class='border'></div>
			                            <span>开通时间：<?php 
echo date('Y-m-d', $res['starttime']);
?></span>
			                            <strong>到期时间：<?php 
echo date('Y-m-d', $res['endtime']);
?></strong>
			                        </div>
						
					</div>
					
				</div>

			</div>
			
			<div class="row">
				<div class="col-sm-12">
					<div class="panel panel-color panel-info"><!-- Add class "collapsed" to minimize the panel -->
						<div class="panel-heading">
							<h3 class="panel-title">卡密充值</h3>
							
							<div class="panel-options">
								<a href="#" data-toggle="panel">
									<span class="collapse-icon">–</span>
									<span class="expand-icon">+</span>
								</a>
							</div>
						</div>
						
						<div class="panel-body">
							
							<p>公告：<?php 
echo $gonggao;
?> </p>
							<br>
							<form action="" method="POST" id="kmcz" role="form" class="validate">
								<div class="input-group">
									<input type="text" placeholder="请输入卡密" class="form-control no-right-border form-focus-info" id="km" name="km"  data-validate="required" data-message-required="请输入卡密信息">
									<span class="input-group-btn">
										<button class="btn btn-info" type="submit">马上充值</button>
									</span>
								</div>
							</form>
			
						</div>

					</div>
				</div>
			</div>

			<div class="row">

				<div class="col-sm-12">

	                    <div class="panel panel-color panel-success"><!-- Add class "collapsed" to minimize the panel -->

	                        <div class="panel-heading">

	                            <h3 class="panel-title">密码修改</h3>

	                            

	                            <div class="panel-options">

	                                <a href="#" data-toggle="panel">

	                                    <span class="collapse-icon">–</span>

	                                    <span class="expand-icon">+</span>

	                                </a>

	                            </div>

	                        </div>
						

						<div class="panel-body">

							<form action="" method="POST" id="newpass" role="form" class="validate">

								<div class="input-group">

									<input type="text" placeholder="请输入新密码" class="form-control no-right-border form-focus-info" id="newpass" name="newpass"  data-validate="required" data-message-required="请输入新密码">

									<span class="input-group-btn">

										<button class="btn btn-info" type="submit">修改密码</button>

									</span>

								</div>

							</form>

			

						</div>
						
                </div>
						
            </div>				

      </div>

			<div class="row">
				<div class="col-sm-12">
	                    <div class="panel panel-color panel-danger"><!-- Add class "collapsed" to minimize the panel -->
	                        <div class="panel-heading">
	                            <h3 class="panel-title">在线充值</h3>
	                            
	                            <div class="panel-options">
	                                <a href="#" data-toggle="panel">
	                                    <span class="collapse-icon">–</span>
	                                    <span class="expand-icon">+</span>
	                                </a>
	                            </div>
	                        </div>
   
	                        <div class="panel-body">
	                            
									<?php 
if ($alpay_on != "") {
} else {
    $hide1 = "hide";
}
?>
									<?php 
if ($config_buy != "") {
} else {
    $hide2 = "hide";
}
?>
									<?php 
if ($config_buy2 != "") {
} else {
    $hide3 = "hide";
}
?>
									<div class="row">
										<div class="col-sm-6">
		                                    <a href="buy.php?user=<?php 
echo $u;
?>&pass=<?php 
echo $p;
?>" class="btn btn-orange btn-icon <?php 
echo $hide1;
?>">
		                                        <i class="fa-credit-card"></i>
		                                        <span>支付宝在线充值</span>
		                                    </a>
		                                    <a target="_blank" href="<?php 
echo $config_buy;
?>" class="btn btn-turquoise btn-icon <?php 
echo $hide2;
?>">
		                                        <i class="fa-link"></i>
		                                        <span>在线充值平台</span>
		                                    </a>
		                                </div>
		                                <div class="col-sm-6  <?php 
echo $hide3;
?>">
		                                	<?php 
echo $config_buy2;
?>
		                                </div>
	                                </div>
	            
	                        </div>

	                    </div>
				</div>
			</div>

			<div class="row">
				<div class="col-sm-6">
					<form action="" method="POST" id="qiandao_f" role="form">
					<input type="hidden" name="qiandao" value="1"/>
					<button type="submit" class="btn btn-turquoise btn-icon btn-icon-standalone btn-block">
						<i class="fa-magic"></i>
						<span style="
    padding-left: 35px;
">每日签到赠送<?php 
echo round($qian_con / 1024 / 1024);
?>MB（已签到<?php 
$qqrs2 = $DB->get_row("SELECT * FROM openvpn where `iuser`='{$u}'");
$qian_num2 = $qqrs2['qian_num'];
echo $qian_num2;
?>次）</span>
					</button>
					</form>
				</div>
				<div class="col-sm-6">
					<a target="_blank" href="/user/reg.php?tj_user=<?php 
echo $res['iuser'];
?>" class="btn btn-pink btn-icon btn-icon-standalone btn-block">
						<i class="fa-group"></i>
						<span style="
    padding-left: 35px;
">推荐送<?php 
echo round($user_cash_con / 1024 / 1024);
?>MB（新用户激活卡密即可）</span>
					</a>
				</div>
			</div>

			<!-- Main Footer -->
			<?php 
include "../assets/copy2.php";
?>
		</div>
		
	</div>

<?php 
include "js.php";
?>

</body>
</html><?php 