<?php
?>
<?php 
$mod = 'blank';
include "../api.inc.php";
$u = daddslashes($_GET['user']);
$p = daddslashes($_GET['pass']);
$res = $DB->get_row("SELECT * FROM `openvpn` where `iuser`='{$u}' && `pass`='{$p}' limit 1");
if (!$res) {
    exit("<script language='javascript'>alert('未正确登录，或用户名或密码不正确！');window.location.href='/user/login.php';</script>");
}
$daili_info = $DB->get_row("SELECT * FROM openvpn where `iuser`='{$u}'");
$daili_info_id = $daili_info['dlid'];
if ($daili_info_id) {
} else {
    $daili_info_id = 0;
}
if ($daili_info_id) {
    $config_dl = $DB->get_row("SELECT * FROM auth_daili WHERE id='{$daili_info_id}' limit 1");
    $config_name = $config_dl['name'];
    $config_qq = $config_dl['qq'];
    $config_tel = $config_dl['tel'];
    $config_buy = $config_dl['buy'];
    $config_buy2 = $config_dl['buy2'];
} else {
    $rs = $DB->get_row("SELECT * FROM website");
    $config_name = $rs['title'];
    $config_qq = $rs['qq'];
    $config_tel = $rs['tel'];
    $rs2 = $DB->get_row("SELECT * FROM auth_config");
    $config_buy = $rs2['shopUrl'];
    $config_buy2 = $rs2['shopCode'];
}
?>
<!DOCTYPE html>
<html lang="en">
<?php 
include '../assets/head2.php';
?>
<body class="page-body">
	
	<div class="page-container"><!-- add class "sidebar-collapsed" to close sidebar by default, "chat-visible" to make chat appear always -->
			
	<?php 
include 'nav.php';
?>
		
		<div class="main-content">
					
			<?php 
include 'info.php';
?>
			
			<!-- Xenon Counter Widget -->
			<div class="row">
					
		                    <div id="addtype_list" class="row">
		                                        <?php 
$rs = $DB->query("SELECT * FROM `kmtype` WHERE `dlid` = '{$daili_info_id}' and i='0'");
while ($res = $DB->fetch($rs)) {
    ?>
		                                        <div class="col-sm-4">
		                                          <div class="xe-widget xe-todo-list xe-todo-list-turquoise">
		                                            <div class="xe-header">
		                                              <div class="xe-icon">
		                                                <i class="fa-credit-card"></i>
		                                              </div>
		                                              <div class="xe-label">
		                                                <strong><?php 
    echo $res['name'];
    ?></strong>
		                                              </div>
		                                            </div>
		                                            <div class="xe-body">
		                                              
		                                              <ul class="list-unstyled">
		                                                <li>
		                                                  <label>
		                                                    <div class="cbr-replaced cbr-checked cbr-turquoise"><div class="cbr-input"><input type="checkbox" class="cbr cbr-done" checked=""></div><div class="cbr-state"><span></span></div></div>
		                                                    <span><?php 
    echo $res['days'];
    ?>天使用时间</span>
		                                                  </label>
		                                                </li>
		                                                <li>
		                                                  <label>
		                                                    <div class="cbr-replaced cbr-checked cbr-turquoise"><div class="cbr-input"><input type="checkbox" class="cbr cbr-done" checked=""></div><div class="cbr-state"><span></span></div></div>
		                                                    <span><?php 
    echo round($res['maxll'] / 1024 / 1024);
    ?>GB流量</span>
		                                                  </label>
		                                                </li>
		                                                <li>
		                                                  <label>
		                                                    <div class="cbr-replaced cbr-checked cbr-turquoise"><div class="cbr-input"><input type="checkbox" class="cbr cbr-done" checked=""></div><div class="cbr-state"><span></span></div></div>
		                                                    <span><?php 
    echo $res['km_rmb'];
    ?>元</span>
		                                                  </label>
		                                                </li>
		                                              </ul>
		                                              
		                                            </div>
						<?php 
    $alpay = $DB->get_row("SELECT * FROM alipay");
    $alpay_on = $alpay['partner'];
    if ($alpay_on != "") {
        $bay_btn = "<a href=pay.php?id=" . $res['id'] . "&user=" . $u . "&pass=" . $p . " type='submit' class='btn btn-white btn-single btn-block'>立即购买</a>";
    } else {
        if ($config_buy != "") {
            $bay_btn = "<a href=" . $config_buy . " target='_blank' type='submit' class='btn btn-white btn-single btn-block'>立即购买</a>";
        }
    }
    ?>
		                                            <div class="xe-footer">
		                                                     <?php 
    echo $bay_btn;
    ?>
		                                            </div>
		                                          </div>
		                                        </div>

		                                        <?php 
}
?>


		                    </div>

			</div>

			<!-- Main Footer -->
			<?php 
include "../assets/copy2.php";
?>
		</div>
		
	</div>

<?php 
include "js.php";
?>

</body>
</html><?php 