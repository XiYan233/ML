
<?php
?>
<?php 
$mod = 'blank';
include "../api.inc.php";
$title = '用户登录';
?><!DOCTYPE html>
<html lang="en">
<?php 
include '../assets/head2.php';
?>
<body class="page-body login-page login-light">

	
	<div class="login-container">
	
		<div class="row">
		
			<div class="col-sm-6 col-sm-offset-3">
			
				<script type="text/javascript">
					jQuery(document).ready(function($)
					{
						// Reveal Login form
						setTimeout(function(){ $(".fade-in-effect").addClass('in'); }, 1);
						
						
						// Validation and Ajax action
						$("form#login").validate({
							rules: {
								user: {
									required: true
								},
								
								pass: {
									required: true
								}
							},
							
							messages: {
								user: {
									required: '此为必填项！'
								},
								
								pass: {
									required: '此为必填项！'
								}
							},
							
						});
						
						// Set Form focus
						$("form#login .form-group:has(.form-control):first .form-control").focus();
					});
				</script>
				
				<!-- Errors container -->
				<div class="errors-container">
				
									
				</div>
				
				<!-- Add class "fade-in-effect" for login form effect -->
				<form action="index.php" method="get" role="form" id="login" class="login-form fade-in-effect">
					
					<?php 
$rs = $DB->get_row("SELECT * FROM website");
$logo = $rs['logo'];
?>
					<div class="login-header">
						<img src="<?php 
echo $logo;
?>" alt="" width="80" />
						<span>您身边的流量领导者!</span>
					</div>
	
					
					<div class="form-group">
						<label class="control-label" for="user">请输入您的帐号</label>
						<input type="text" class="form-control" name="user" id="user" autocomplete="off" />
					</div>
					
					<div class="form-group">
						<label class="control-label" for="pass">请输入您的密码</label>
						<input type="password" class="form-control" name="pass" id="pass" autocomplete="off" />
					</div>
					
					<div class="form-group">
						<button type="submit" class="btn btn-info  btn-block text-center">
							<i class="fa-lock"></i>
							马上登录
						</button>
					</div>
					
					<div class="login-footer text-center">
						<a href="#">如忘记密码，请与代理商联系找回！</a>
						
						<div class="info-links hide">
							<a href="#">ToS</a> -
							<a href="#">Privacy Policy</a>
						</div>
						
					</div>
					
				</form>
				
				<!-- External login -->
				<div class="external-login">
					<a href="reg.php" class="btn btn-secondary text-center">
						<i class="fa-edit"></i>
						还没有帐号？立即注册吧！
					</a>
					
					<!-- 
					<a href="#" class="twitter">
						<i class="fa-twitter"></i>
						Login with Twitter
					</a>
					
					<a href="#" class="gplus">
						<i class="fa-google-plus"></i>
						Login with Google Plus
					</a>
					 -->
				</div>
				
			</div>
			
		</div>
		
	</div>



	<!-- Bottom Scripts -->
	<script src="../assets/js/bootstrap.min.js"></script>
	<script src="../assets/js/TweenMax.min.js"></script>
	<script src="../assets/js/resizeable.js"></script>
	<script src="../assets/js/joinable.js"></script>
	<script src="../assets/js/xenon-api.js"></script>
	<script src="../assets/js/xenon-toggles.js"></script>
	<script src="../assets/js/jquery-validate/jquery.validate.min.js"></script>
	<script src="../assets/js/toastr/toastr.min.js"></script>


	<!-- JavaScripts initializations and stuff -->
	<script src="../assets/js/xenon-custom.js"></script>

</body>
</html><?php 