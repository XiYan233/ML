<?php
?>
<?php 
$mod = 'blank';
include "../api.inc.php";
$title = '代理中心';
$dlid = $_SESSION['dlid'];
$row = $DB->get_row("SELECT * FROM auth_daili WHERE id='{$dlid}' limit 1");
$rs = $DB->get_row("SELECT * FROM auth_config WHERE 1");
$vip = $row['vip'];
$rmb = $row['rmb'];
$income = $row['income'];
if ($vip == 1) {
    $dljg = $rs['dl1'];
    $dljgs = $rs['dls1'];
    $wx = $rs['wx1'];
    $v = "<font>铜牌代理</font>";
} elseif ($vip == 2) {
    $dljg = $rs['dl2'];
    $dljgs = $rs['dls2'];
    $wx = $rs['wx2'];
    $v = "<font>银牌代理</font>";
} elseif ($vip == 3) {
    $dljg = $rs['dl3'];
    $dljgs = $rs['dls3'];
    $wx = $rs['wx3'];
    $v = "<font>金牌代理</font>";
} elseif ($vip == 0) {
    $dljg = $rs['dl0'];
    $dljgs = $rs['dls0'];
    $wx = $rs['wx0'];
    $v = "<font>普通代理</font>";
} elseif ($vip == 4) {
    $dljg = $rs['dl4'];
    $dljgs = $rs['dls4'];
    $wx = $rs['wx4'];
    $v = "<font>钻石代理</font>";
} elseif ($vip == 5) {
    $dljg = $rs['dl5'];
    $dljgs = $rs['dls5'];
    $wx = $rs['wx5'];
    $v = "<font>至尊代理</font>";
}
$config = $DB->get_row("SELECT * FROM auth_config");
$gonggao = $config['gg'];
$shopUrl = $config['shopUrl'];
$shopCode = $config['shopCode'];
if ($dlid != "") {
} else {
    exit("<script language='javascript'>window.location.href='./login.php';</script>");
}
if ($_POST['pass'] && $_POST['newpass']) {
    $pass = daddslashes($_POST['pass']);
    $newpass = daddslashes($_POST['newpass']);
    if ($DB->query("update `auth_daili` set `pass` ='{$newpass}' where `id`='{$dlid}' and `pass`='{$pass}' limit 1")) {
        exit("<script language='javascript'>alert('密码修改成功！');history.go(-1);</script>");
    } else {
        exit("<script language='javascript'>alert('密码修改失败！');history.go(-1);</script>");
    }
}
$rmb = $row['rmb'];
if ($_GET['do'] == "cz") {
    $km = daddslashes($_POST['km']);
    $kmrow = $DB->get_row("SELECT * FROM auth_kms WHERE km='{$km}' and kind=2 limit 1");
    if (!$kmrow) {
        exit("<script>alert('卡密不存在');window.location.href='/daili';</script>");
    } elseif ($kmrow['isuse'] > 0) {
        exit("<script>alert('卡密已被使用');window.location.href='/daili';</script>");
    } else {
        $value = $kmrow['value'];
        $now_rmb = $rmb + $value;
        $DB->query("UPDATE auth_daili SET rmb='{$now_rmb}' WHERE id='{$dlid}'");
        $DB->query("UPDATE auth_kms SET isuse=1,usetime='" . date("Y-m-d H:i:s") . "',user='{$row['user']}' WHERE km='{$km}' and kind=2");
        if ($row['tj_user']) {
            $rmb2 = $value * $conf_rate;
            $sql2 = $DB->query("update `auth_daili` set `tj_rmb`=`tj_rmb`+{$rmb2} where `user`='{$row['tj_user']}'");
        }
        wlog('代理充值', '代理' . $row['user'] . '使用卡密' . $km . '充值' . $value . '元[' . $date . ']');
        exit("<script>alert('成功充值" . $value . "元');window.location.href='/daili';</script>");
    }
}
$count = $DB->count("SELECT count(*) from `openvpn` WHERE dlid='{$dlid}'");
$count2 = $DB->count("SELECT count(*) from `openvpn` WHERE i=0 and  dlid='{$dlid}'");
$countkm = $DB->count("SELECT count(*) from `auth_kms` WHERE daili='{$dlid}'");
$countkm2 = $DB->count("SELECT count(*) from `auth_kms` WHERE isuse=0 and daili='{$dlid}'");
$alpay = $DB->get_row("SELECT * FROM alipay");
$alpay_on = $alpay['partner'];
?>
<!DOCTYPE html>
<html lang="en">
<?php 
include '../assets/head2.php';
?>
<body class="page-body">
    
    <?php 
include 'nav.php';
?>

    <div class="page-container"><!-- add class "sidebar-collapsed" to close sidebar by default, "chat-visible" to make chat appear always -->
            
        <div class="main-content">
                    
            
            <h3 id="layout-toggles">
                代理中心
                <br />
            </h3>
            
            <br />

            <div class="row">
                
                <div class="col-sm-6">
                    
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            您的信息
                        </div>
                        
                        <div class="panel-body">
                            
                            <div class="row">
                                <div class="col-sm-12">
                                    
                                    <ul class="list-unstyled line-height-default" style="margin-bottom: 2px;">
                                        <!--li>
                                            代理ID：
                                            <span class="label label-default pull-right"><?php 
echo $_SESSION['dlid'];
?></span>
                                        </li-->
                                        <li>
                                             VIP等级：
                                            <span class="label label-primary pull-right"><?php 
echo $v;
?></span>
                                        </li>
                                        <li>
                                            拿货价：
                                            <span class="label label-secondary pull-right" style="margin-left: 10px;"><?php 
echo "" . $wx . "元/无限";
?></span>
                                            <span class="label label-secondary pull-right"><?php 
echo $dljg . "元/天 + " . $dljgs . "元/GB";
?></span>
                                        </li>
                                        <li>
                                            账户余额：
                                            <span class="label label-warning pull-right"><?php 
echo $rmb . "元";
?></span>
                                        </li>
                                        <li>
                                            支付宝收入：
                                            <span class="label label-blue pull-right"><?php 
echo $income . "元";
?></span>
                                        </li>
                                        <?php 
echo '<li>你的推荐余额：<span class="label label-danger pull-right">' . $row['tj_rmb'] . '</span></li><li>你的推荐链接：<a href="./reg.php?tj_user=' . $row['user'] . '" target="_blank"><span class="label label-info pull-right">点击这里</span></a></li>';
?>
                                    </ul>
                                    
                                </div>
                            </div>
                            
                        </div>
                        
                    </div>
                </div>

                <div class="col-sm-6">

                    <div class="panel panel-color panel-info"><!-- Add class "collapsed" to minimize the panel -->
                        <div class="panel-heading">
                            <h3 class="panel-title">卡密充值</h3>
                            
                            <div class="panel-options">
                                <a href="#" data-toggle="panel">
                                    <span class="collapse-icon">–</span>
                                    <span class="expand-icon">+</span>
                                </a>
                            </div>
                        </div>
                        
                        <div class="panel-body">
                            
                            <p>如需购买卡密请联系管理员</p>
                            <br>
                            <form action="?do=cz" method="POST" class="validate">
                                <div class="input-group">
                                    <input type="text" placeholder="请输入卡密" class="form-control no-right-border form-focus-info" id="km" name="km" data-validate="required" data-message-required="请输入卡密信息">
                                    <span class="input-group-btn">
                                        <button class="btn btn-info" type="submit">马上充值</button>
                                    </span>
                                </div>
                            </form>
            
                        </div>

                    </div>

                    <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert">
                            <span aria-hidden="true">×</span>
                            <span class="sr-only">Close</span>
                        </button>
                        
                        <strong>公告:</strong> <?php 
echo $gonggao;
?>
                    </div>

                </div>
            </div>

            <div class="row">
                <div class="col-sm-6">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="xe-widget xe-progress-counter xe-progress-counter-purple" data-count=".num" data-from="0" data-to="<?php 
echo $count;
?>" data-suffix="" data-duration="4">
                                
                                <div class="xe-background">
                                    <i class="linecons-lightbulb"></i>
                                </div>
                                
                                <div class="xe-upper">
                                    <div class="xe-icon">
                                        <i class="linecons-lightbulb"></i>
                                    </div>
                                    <div class="xe-label">
                                        <strong class="num">0</strong>
                                        <span>已注册帐号数量</span>
                                    </div>
                                </div>

                                <div class="xe-progress">
                                    <span class="xe-progress-fill" data-fill-from="0" data-fill-to="<?php 
echo round($count2 / $count * 100);
?>" data-fill-unit="%" data-fill-property="width" data-fill-duration="3" data-fill-easing="true" style="width: 0%;"></span>
                                </div>

                                <div class="xe-lower">
                                    <strong><?php 
echo $count2;
?>个帐号已停用</strong>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="xe-widget xe-progress-counter xe-progress-counter-turquoise" data-count=".num" data-from="0" data-to="<?php 
echo $countkm;
?>" data-suffix="" data-duration="3">
                                
                                <div class="xe-background">
                                    <i class="linecons-attach"></i>
                                </div>
                                
                                <div class="xe-upper">
                                    <div class="xe-icon">
                                        <i class="linecons-attach"></i>
                                    </div>
                                    <div class="xe-label">
                                        <strong class="num">0</strong>
                                        <span>已生成卡密数量</span>
                                    </div>
                                </div>
                                
                                <div class="xe-progress">
                                    <span class="xe-progress-fill" data-fill-from="0" data-fill-to="<?php 
echo round($countkm2 / $countkm * 100);
?>" data-fill-unit="%" data-fill-property="width" data-fill-duration="3" data-fill-easing="true" style="width: 0%;"></span>
                                </div>
                                
                                <div class="xe-lower">
                                    <strong><?php 
echo $countkm2;
?>个卡密未使用</strong>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="panel panel-color panel-danger"><!-- Add class "collapsed" to minimize the panel -->
                        <div class="panel-heading">
                            <h3 class="panel-title">余额充值</h3>
                            
                            <div class="panel-options">
                                <a href="#" data-toggle="panel">
                                    <span class="collapse-icon">–</span>
                                    <span class="expand-icon">+</span>
                                </a>
                            </div>
                        </div>
                        
                        <div class="panel-body">
                            <?php 
if ($alpay_on != "") {
} else {
    $hide1 = "hide";
}
?>
                            <?php 
if ($shopUrl != "") {
} else {
    $hide2 = "hide";
}
?>
                            <?php 
if ($shopCode != "") {
} else {
    $hide3 = "hide";
}
?>
                            <div class="row">
                                <div class="col-sm-5">
                                    <a href="buy.php" class="btn btn-orange btn-icon <?php 
echo $hide2;
?>">
                                        <i class="fa-credit-card"></i>
                                        <i class="fa-link"></i>
                                        <span>在线充值</span>
                                    </a>
                                </div>
                                <div class="col-sm-7 <?php 
echo $hide3;
?>">
                                <?php 
echo $shopCode;
?>
                                </div>
                            </div>
            
                        </div>

                    </div>
                </div>
            </div>

             <?php 
include "../assets/copy2.php";
?>
             
        </div>
        
    </div>
    
    <!-- Bottom Scripts -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/TweenMax.min.js"></script>
    <script src="../assets/js/resizeable.js"></script>
    <script src="../assets/js/joinable.js"></script>
    <script src="../assets/js/xenon-api.js"></script>
    <script src="../assets/js/xenon-toggles.js"></script>

    <script src="../assets/js/jquery-validate/jquery.validate.min.js"></script>

    <script src="../assets/js/xenon-widgets.js"></script>

    <!-- JavaScripts initializations and stuff -->
    <script src="../assets/js/xenon-custom.js"></script>

</body>
</html><?php 