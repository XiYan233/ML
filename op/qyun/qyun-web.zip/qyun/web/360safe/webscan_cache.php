<?php
define('WEBSCAN_U_KEY', 'dcc20a8db07667376916d96d6754aa70');
define('WEBSCAN_API_LOG', 'http://safe.webscan.360.cn/papi/log/?key='.WEBSCAN_U_KEY);
define('WEBSCAN_UPDATE_FILE','http://safe.webscan.360.cn/papi/update/?key='.WEBSCAN_U_KEY);
$webscan_switch=1;
$webscan_post=1;
$webscan_get=1;
$webscan_cookie=1;
$webscan_referre=1;
$webscan_white_directory='';
$webscan_white_url = array('');